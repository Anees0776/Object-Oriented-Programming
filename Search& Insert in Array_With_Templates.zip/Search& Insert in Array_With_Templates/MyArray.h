#pragma once
#include "Array.h"

template <class t>
class MyArray :public Array<t>
{

public:
	MyArray(int size);
	~MyArray();
	void addElement(t num);
	bool insertAt(int index, t value);
	t removeElementFromStart();
	bool isFull();
	bool isEmpty();
	int size();
	virtual t last();
	bool search(t value);
	void display();
};

template <class t>
MyArray<t>::MyArray(int size) :Array<t>(size)
{

}
template <class t>
MyArray<t>::~MyArray()
{

}

template <class t>
void MyArray<t>::addElement(t num)
{
	if (MyArray<t>::currentSize < MyArray<t>::maxSize)
	{
		MyArray<t>::arr[MyArray<t>::currentSize] = num;
		MyArray<t>::currentSize++;
	}
	else
	{
		cout << "Array is full. Cann't add element " << endl;
	}
}

template <class t>
bool MyArray<t>::insertAt(int index, t value)
{

	cout << "Current Size: " << MyArray<t>::currentSize << ", Max Size: " << MyArray<t>::maxSize << endl;

	if (index < 0 || index > MyArray<t>::currentSize)
	{
		cout << "Failed: Index out of range! " << endl;
		return false;
	}

	if (MyArray<t>::currentSize >= MyArray<t>::maxSize)
	{
		cout << "Failed: Array is full! " << endl;
		return false;
	}

	for (int i = MyArray<t>::currentSize; i > index; i--)
	{
		MyArray<t>::arr[i] = MyArray<t>::arr[i - 1];
	}

	MyArray<t>::arr[index] = value;
	MyArray<t>::currentSize++;

	cout << "Insertion successful! " << endl;
	return true;
}

template <class t>
bool MyArray<t>::isFull()
{
	return MyArray<t>::currentSize == MyArray<t>::maxSize;
}

template <class t>
bool MyArray<t>::isEmpty()
{
	return MyArray<t>::currentSize == 0;
}

template <class t>
t MyArray<t>::removeElementFromStart()
{
	if (MyArray<t>::currentSize > 0)
	{
		t removed = MyArray<t>::arr[0];
		for (int i = 0; i < MyArray<t>::currentSize - 1; i++)
			MyArray<t>::arr[i] = MyArray<t>::arr[i + 1];
		MyArray<t>::currentSize--;
		return removed;
	}
	return t();
}

template <class t>
int MyArray<t>::size()
{
	return MyArray<t>::currentSize;
}

template <class t>
t MyArray<t>::last()
{
	if (MyArray<t>::currentSize > 0)
	{
		return MyArray<t>::arr[MyArray<t>::currentSize - 1];
	}
	return t();
}

template <typename t>
bool MyArray<t>::search(t value)
{
	for (int i = 0; i < MyArray<t>::currentSize; i++)
	{
		if (MyArray<t>::arr[i] == value)
			return true;
	}
	return false;
}


template <class t>
void MyArray<t>::display()
{
	for (int i = 0; i < MyArray<t>::currentSize; i++)
	{
		cout << MyArray<t>::arr[i] << " ";
	}
	cout << endl;
}



