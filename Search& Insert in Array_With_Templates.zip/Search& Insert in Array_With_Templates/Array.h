#pragma once
#include<iostream>
using namespace std;

template <typename t>
class Array
{
protected:
	t* arr;
	int maxSize;
	int currentSize;
public:
	Array(int size);
	virtual void addElement(t num) = 0;
	virtual bool insertAt(int index, t value) = 0;
	virtual t removeElementFromStart() = 0;
	virtual bool isFull() = 0;
	virtual bool isEmpty() = 0;
	virtual int size() = 0;
	virtual t last() = 0;
	virtual bool search(t value) = 0;
	virtual void display() = 0;
	~Array();
};

template <typename t>
Array<t>::Array(int size)
{
	currentSize = 0;
	maxSize = size;
	arr = new t[maxSize];
}

template <typename t>
Array<t>::~Array()
{
	delete[] arr;
}

