#include "MyArray.h"
#include<iostream>
using namespace std;

int main()
{
    MyArray<int> obj(5);
    int index, value;
    obj.addElement(10);
    obj.addElement(20);
    obj.addElement(30);
    obj.addElement(40);
    cout << "Enter index and value to insert: ";
    cin >> index >> value;
    if (obj.insertAt(index, value))
    {
        cout << "Inserted successfully! " << endl;
    }
    else
    {
        cout << "Insertion failed! Invalid index. " << endl;
    }
    cout << "Updated List: ";
    obj.display();

    cout << "Removing first element " << endl;
    obj.removeElementFromStart();
    obj.display();

    cout << "Last element: " << obj.last() << endl;

    cout << "Enter value to search: ";
    cin >> value;
    if (obj.search(value))
    {
        cout << "Value Found " << endl;
    }
    else
    {
        cout << "Value Not Found " << endl;
    }


    return 0;
}
