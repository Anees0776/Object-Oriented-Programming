#include "Array.h"
#include "MyArray.h"

int main(){
	MyArray<int> obj(5);
	
	obj.addElementAtFirstIndex(99);
	cout << endl << "After Adding element at first index\n\n";
	obj.display();
	cout << endl << "After Adding element at last index\n\n";
	obj.addElementAtLastIndex(100);
	obj.display();
	cout << endl << "After removing element at end index\n\n";
	obj.removeElementFromEnd();
	obj.display();
	cout << endl << "After removing element from first index\n\n";
	obj.removeElementFromStart();
	obj.display();
	return 0;
}