#pragma once
#include "Array.h"

template <class t>
class MyArray:public Array<t> 
{

public:
	MyArray(int size);
	void addElementAtFirstIndex(t num);
	bool isFull();
	bool isEmpty();
	t removeElementFromEnd();
	t removeElementFromStart();
	void addElementAtLastIndex(t num);
	void display();
};

template <class t>
MyArray<t>::MyArray(int size):Array<t>(size) 
{

}

template <class t>
void MyArray<t>:: addElementAtFirstIndex(t num) 
{
         MyArray<t>::arr[0] = num;
}

template <class t>
bool MyArray<t>:: isFull() 
{
	if (MyArray<t>::currentSize == MyArray<t>::maxSize) {
		cout << "Array is Full\n";
		return true;
	}
	else
	{
		cout << "Array is Empty\n";
		return false;
	}
}

template <class t>
bool MyArray<t>::isEmpty() {
	if (MyArray<t>::currentSize == 0)
	{
		cout << "Array is Empty\n";
		return true;
	}
	else
	{
		cout << "Array is not Empty\n";
		return false;
	}
}

template <class t>
void MyArray<t>::display() 
{
	cout << "Maximum Size: " << MyArray<t>::maxSize << endl;
	
	cout << "Removed Value From Start: " << MyArray<t>::removeElementFromStart() << endl;
	cout << "Removed Value From End: " << MyArray<t>::removeElementFromEnd() << endl;
	for (int i = 0; i < MyArray<t>::maxSize; i++)
	{
		cout << "Element " << i + 1 << ". " << MyArray<t>::arr[i] << endl;
	}
}

template <class t>
t MyArray<t>::removeElementFromEnd()
{
	MyArray<t>::currentSize--;
}

template <class t>
t MyArray<t>::removeElementFromStart()
{
	return 
}

template <class t>
void MyArray<t>::addElementAtLastIndex(t num)
{
	Array<t>::arr[Array<t>::maxSize] = num;
}