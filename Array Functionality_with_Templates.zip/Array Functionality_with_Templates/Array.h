#pragma once
#include<iostream>
using namespace std;

template <typename t>
class Array 
{
protected:
	t* arr;
	int maxSize;
	int currentSize;
public:
	Array( int size);
	virtual void addElementAtFirstIndex(t num) = 0;
	virtual void addElementAtLastIndex(t num) = 0;
	virtual t removeElementFromEnd() = 0;
	virtual t removeElementFromStart() = 0;
	virtual bool isFull() = 0;
	virtual bool isEmpty() = 0;
};

template <typename t>
Array<t>::Array(int size) 
{
	arr = new t[maxSize];
	maxSize = size;
}